function d = FSD(data)


% A_hat = data * data';
A_hat = (1/length(data))*(data * data');


[M, N] = size(data);        % in this script M = amount of nodes, N = amount of data
c_N = sqrt(log(N));

%
conti = 1;
m = 0;
 
while conti==1
    valsRR = lanczos(A_hat, m);      % step m in lanczos algorithm

    for d_estim = 1 : m-1
        % calculate the statistic
        aux1 = (M-d_estim)^-1 * (norm(A_hat,'fro').^2 - sum(valsRR(1:d_estim).^2));   
        aux2 = (M-d_estim)^-1 * (trace(A_hat) - sum(valsRR(1:d_estim)));
        estad = N * (M-d_estim) * (0.5*log(aux1)-log(aux2));
        
        
        % calculate the threshold
        gr_lib = 0.5 * (M-d_estim) * (M-d_estim+1) - 1;    
        thresh = chi2inv(0.90, gr_lib) / c_N;

        if (estad <= thresh)
            d = d_estim;
            conti = 0; 
            break;
        end
        if (abs(valsRR(1)-valsRR(2)) < min(valsRR))
            d = m-4;
            conti=0;
            break;
        end
    end 
    m = m+1;
    if m==length(A_hat)+1
        conti = 0;
        d = length(A_hat);
    end

end 