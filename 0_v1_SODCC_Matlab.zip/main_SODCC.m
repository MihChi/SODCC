% Script used to show how the SODCC algorithm can be used for computer simulations.  

                      
%% path
path('clustering_functions', path)

%% initial parameters for SODCC
Pi = 0.35;          % probability of a node being selected as CH in the "Cluster initialization" phase
Ni_1st = 3;         % minimum number of initial nodes in a cluster
N_rep = 3;          % number of repetitions allowed for the "Cluster initialization" phase


%% read data file 
% consider this main script as an example where the data used is Wind data
% obtained from ERA-Interim database [Dee2011] with the following
% characteristics:
%       - Jan 1979 -- 00:00, 06:00, 12:00, 18:00 -- step = 0
%       - 10 metre U wind component and 10 metre V wind component
%       - Custom area bounded by: 
%           - parallels 35�N and 44�N
%           - meridians 10�W and 6�E
%       - grid = 0.5x0.5
%
% Feel free to use other datasets, but consider to adapt the data
% representation such that all the scripts and functions can understand it.
% 
%
% [Dee2011] - Dee, D.P., Uppala, S.M., et al.: The ERA?Interim reanalysis:
% Configuration and performance of the data assimilation system. Quarterly
% Journal of the Royal Meteorological Society 137(656), 553?597 (2011)  


input_data = 'input.nc';    
output_data = 'output.mat';  

longitude = ncread(input_data, 'longitude');
latitude = ncread(input_data, 'latitude');
time = ncread(input_data, 'time');
u10 = ncread(input_data, 'u10');
v10 = ncread(input_data, 'v10');
ws = sqrt(u10.^2 + v10.^2);             % wind speed


%% prepare matlab data representation  

% node ID
estac = (1:length(longitude)*length(latitude))';            

% matrix that contains node ID and its position
pos = zeros(length(estac),3);
pos(:,1) = estac;
pos(:,2) = reshape(repmat(latitude, 1, length(longitude)), 1,[])';         % latitude
pos(:,3) = reshape(repmat(longitude, 1, length(latitude))', [],1);         % longitude

% input data structure -- contains all the data used for each simulation
d_ws = {};

d_ws.year = 1979;   d_ws.month = 1;
d_ws.time = time;   d_ws.estac = estac;     d_ws.pos = pos;

d_ws.data = reshape(permute(ws, [2 1 3]), [length(estac),length(time)]);

% substract data mean 
d_ws.avg = mean(d_ws.data,2); [~,sss] = size(d_ws.data);
d_ws.data = d_ws.data - repmat(d_ws.avg,1,sss); 

% save also initial parameters 
d_ws.Pi = Pi;
d_ws.Ni_1st = Ni_1st;
d_ws.N_rep = N_rep;

save(output_data, 'd_ws');

clear latitude longitude time u10 v10 ws wd wd_deg estac pos Pi Ni_1st N_rep sss

%% start one SODCC simulation
% 

[nodes_CH_ini, CHs] = cluster_initialization(d_ws.Pi, d_ws.pos, length(d_ws.estac), d_ws.N_rep);

nodes_CH_end = cluster_growing(nodes_CH_ini, CHs, length(d_ws.estac), d_ws.data, d_ws.pos);

save(output_data, 'nodes_CH_end', '-append');
