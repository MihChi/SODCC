function node_CH = cluster_growing(node_CH, CHs, N, data, pos)

% cluster growing phase of SODCC 
% Input
%         node_CH = OUTPUT OF CLUSTER INITIALIZATION STAGE. cell type
%                   variable that saves the row of pos matrix of the
%                   cluster heads and of the nodes that belong to each
%                   cluster.    
%         CHs = OUTPUT OF CLUSTER INITIALIZATION STAGE. vector type
%               variable that contians the row of pos matrix of the cluster
%               heads. usefull for cluster growing phase  
%         N = number of nodes in the network
%         data = data used for the clustering
%         pos = matrix that contains node ID and its position
%        
% Output
%         node_CH = this is the main output of SODCC. cell type
%                   variable that saves the row of pos matrix of the
%                   cluster heads and of the nodes that belong to each
%                   cluster. 

actual_size = 1;
all_ok = 0;


while ~all_ok
    size_cl = cellfun(@length, node_CH);
    
    if max(size_cl) < actual_size
        all_ok = 1;
        break;
    end
    
    signal_subspace_cluster = zeros(1,N);
    to_fusion = [];
    
    actual_CHs = find(size_cl == actual_size);
    
    % compute the FSD dimension and check if a cluster fusion is needed
    for i=1:length(actual_CHs)
        
        ch = actual_CHs(i);
        nodes = node_CH{ch};
        
        M = 4*length(nodes);        
        data_ = data(nodes,1:M);
        signal_subspace_cluster(ch) = FSD(data_);
        
        if signal_subspace_cluster(ch) >= size_cl(ch)
            to_fusion = [to_fusion; ch];
        end
       
    end
    
    % cluster fusions
    i = 1;
    while i <= length(to_fusion)
      
        ch = to_fusion(i);
        x_act = pos(ch,2);
        y_act = pos(ch,3);
        
        [~, ind_dist] = sort(sqrt((pos(CHs,2) - x_act).^2 + (pos(CHs,3) - y_act).^2));
        ch_cercano = CHs(ind_dist(2));       % index 1 is actual node
        
        node_CH{ch_cercano} = [node_CH{ch_cercano}; node_CH{ch}];    % fusion
        node_CH{ch} = [];   % erase old cluster
        CHs(CHs==ch)=[];    % erase old CH
        
        % if ch_cercano also needs a fusion, we skip it because it just got bigger
        if ismember(ch_cercano, to_fusion)
            to_fusion(ch_cercano == to_fusion) = [];
        end
        
        i = i+1;
    end
    
    actual_size = actual_size + 1;
    
end