function [node_CH, CHs] = cluster_initialization(Pi, pos, N, N_rep)
% cluster initialization phase of SODCC -- no data is taken into account 
% Input
%         Pi = probability of a node being selected as CH 
%         pos = matrix that contains node ID and its position
%         N = number of nodes in the network
%         N_rep = number of repetitions allowed
% Output
%         node_CH = cell type variable that saves the row of pos matrix of
%                    the cluster heads and of the nodes that belong to each
%                    cluster. 
%         CHs = vector type variable that contians the row of pos matrix of
%               the cluster heads. usefull for cluster growing phase
%
%  Output example:
%
%  node_CH = 
% 
%   Columns 1 through 10
% 
%     [1]    [3x1 double]    []    [4]    [2x1 double]    []    []    [2x1 double]    []    [2x1 double]
% 
%   Columns 11 through 22
% 
%     []    []    [13]    [14]    [15]    []    [2x1 double]    []    [19]    []    [21]    []
% 
%   Columns 23 through 31
% 
%     [2x1 double]    [2x1 double]    [25]    []    []    []    [3x1 double]    [30]    [31]
% 
%   Columns 32 through 39
% 
%     [3x1 double]    []    [2x1 double]    [2x1 double]    [2x1 double]    [2x1 double]    [38]    [39]
% 
%   Columns 40 through 47
% 
%     [40]    []    [42]    []    []    [3x1 double]    []    [47]
%
%  nodos_CH{2}
% 
%   ans =
% 
%      2
%      6
%     12
%
%   Explanation: 
%              1)  The node whose location is on the first row of matrix
%              pos is a CH and its cluster size is 1. The node whose
%              location is on the second row of matrix pos is a CH and its
%              cluster size is 3. The node whose location is on the third
%              row of matrix pos is not a CH.
%              2)  The cluster whos cluster head is the node whose location
%              is on the second row of matrix pos includes the nodes 2, 6
%              and 12.
%
        
node_CH = cell(1,N);   

CHs = [];
distances = [];
conflict = [];

for intento = 1: N_rep
    
%     disp('1. Not used nodes decide if they are CH or not')
    available_nodes = freeNodes(node_CH);
    if isempty(available_nodes)
%         disp('No more free nodes left');
        break
    end
    if intento < N_rep
        CH_new = available_nodes(rand(1,length(available_nodes)) < Pi);
    else
        CH_new = available_nodes;
    end
    
    CHs = [CHs CH_new];

%     disp('2. The new CH compute their favourite nodes')
    distances = computeDistances(pos, CH_new, distances, N);

    [~, indices_] = sort(distances);

    
%     disp('3. The conflicts are detected')
    conflict = conflictDetection(conflict, indices_, CH_new, CHs);

% 
%     disp('4. Node asignation to the clusters')
%     disp('      Case 1. conflictos==0 --> Is a simple node and it accepts the CH')
%     disp('      Case 2. conflictos==-1 --> This is a CH node, so no answer for the request')
%     disp('      Case 3. conflictos==-2 --> This node is required by multiple CHs. It only answers the first request')
    
    [conflict, node_CH] = nodeAsignation(conflict, node_CH, indices_, CH_new, CHs, available_nodes);
    
end