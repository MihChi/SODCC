function available_nodes = freeNodes(nodos_CH)
used_nodes = [];
for i = 1:length(nodos_CH)
    used_nodes = [used_nodes; nodos_CH{i}];
end
used_nodes = sort(used_nodes);
available_nodes = find(~ismember(1:length(nodos_CH), used_nodes));
