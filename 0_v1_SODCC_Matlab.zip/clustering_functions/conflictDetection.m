function conflicts = conflictDetection(conflicts, indices_, CH_new, CH_possible)

for i = length(CH_possible)-length(CH_new)+1:length(CH_possible)
    nodos = indices_(2:3,i);
    aux = ismember(nodos, CH_possible);
    n1 = ismember(nodos(1), indices_(2:3, [1:i-1 i+1:end])) & ~ismember(nodos(1), CH_possible);
    n2 = ismember(nodos(2), indices_(2:3, [1:i-1 i+1:end])) & ~ismember(nodos(2), CH_possible);
    conflicts(:,i) = [indices_(1,i); (-1 * aux + -2 * [n1;n2])];
end