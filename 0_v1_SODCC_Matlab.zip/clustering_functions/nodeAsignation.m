function [conflicts, node_CH] = nodeAsignation(conflicts, node_CH, indices_, CH_new, CH_possible, available_nodes)

for i=length(CH_possible)-length(CH_new)+1:length(CH_possible)
    ch_ = indices_(1,i);
    node_CH = addNode(node_CH, ch_, []);
    for ii = 2:3    % the third row is the last (for now)
        con_ = conflicts(ii,i);
        n_ = indices_(ii,i);
        switch con_
            case 0
                node_CH = addNode(node_CH, ch_, n_);
            case -1
                % n_ is a CH_tentativo
                conflicts(ii,i) = -3;      % not usable for this CH because is a CH
            case -2
                if ismember(n_,available_nodes)
                    % n_ is required by multiple CHs
                    [r,c] = find(indices_(2:3,:)==n_);  % c=possibilities
                    o_ = randperm(length(c)); % the order
                    
                    conflicts(r(o_(1))+1,c(o_(1))) = 0;
                    node_CH = addNode(node_CH, conflicts(1,c(o_(1))), n_);
                    
                    conflicts(r(o_(2:end))+1, c(o_(2:end))) = -3; % not usable for this CH
                    % +1 becaues find es between rows 2:3
                else
                    conflicts(ii,i) = -3;      % not usable for this CH because it was used before
                end
        end
    end
end