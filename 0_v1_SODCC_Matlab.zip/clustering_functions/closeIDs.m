function r = closeIDs(i,p,des, pos_centr)

if size(i,2)>1, i=i'; end
i = pos_centr(i,1);

% BB = repmat(-(p*des):des:+p*des, length(i), 1);
% CC = repmat(i, 1, 2*p+1);
% 
% DD = repmat(BB+CC, 1, 2*p+1); clear BB CC
% 
% AA =repmat(reshape(repmat((-p:p),2*p+1,1), 1,[]), length(i),1);
% 
% r = DD+AA; clear AA DD
% 
% % quito nodos que no se usan (aqui tb quito los que son de los bordes)
% % r(~ismember(r, pos_centr(:,1))) = NaN;
% [~, r] = ismember(r,pos_centr(:,1));
% 
% rr = reshape(r,2*p+1,2*p+1)';
% 
% first_line = 1:des:size(pos_centr,1);
% last_line = des:des:size(pos_centr,1);
% 
% desc_first = first_line;
% desc_last = last_line;
% for j = 1:p
%     desc_first = horzcat(desc_first, desc_first+j);
%     desc_last = horzcat(desc_last, desc_last-j);
% end
% 
% if ismember(i,desc_first)
%     for j = 1:length(rr)
%         if sum(ismember(first_line,rr(j,:)))>0
%             rr(1:j-1,:)=0;
%         end
%     end
% end
% 
% if ismember(i,desc_last)
%     for j = 1:length(rr)
%         if sum(ismember(last_line,rr(j,:)))>0
%             if j<2*p+1
%                 rr(j+1:end,:)=0;
%             end
%         end
%     end
% end
% 
% 
% r = rr;

rr_tot = reshape(1:size(pos_centr,1),des,[]);
[raw,col] = find(rr_tot==i);

rr_tot = vertcat(zeros(p,size(rr_tot,2)), rr_tot, zeros(p,size(rr_tot,2)));
rr_tot = horzcat(zeros(size(rr_tot,1),p), rr_tot, zeros(size(rr_tot,1),p));

r = rr_tot(raw:raw+2*p, col:col+2*p);       % fila del id = mod(i,19); columna del id = floor(i/19)+1
