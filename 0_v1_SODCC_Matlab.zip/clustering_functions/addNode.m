function nodos_CH = addNode(nodos_CH, ch_, n_)

if isempty(nodos_CH{ch_})     % new cluster
    nodos_CH{ch_} = [ch_; n_];
else                          % new node
    nodos_CH{ch_} = [nodos_CH{ch_}; n_];
    nodos_CH{ch_} = [nodos_CH{ch_}(1); unique(nodos_CH{ch_}(2:end))];   % unique nodes
end
