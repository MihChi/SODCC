function distances = computeDistances(pos_CH, CH_new, distances, N_SEN)

resta_x = (repmat(pos_CH(:,2), 1, length(CH_new))-repmat(pos_CH(CH_new,2)',N_SEN, 1));
resta_y = (repmat(pos_CH(:,3), 1, length(CH_new))-repmat(pos_CH(CH_new,3)',N_SEN, 1));
distances = [distances sqrt(resta_x.^2 + resta_y.^2)];
% distancias = sqrt(resta_x.^2 + resta_y.^2);