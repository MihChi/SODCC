function f = plot_map(latlim, lonlim, varargin)

switch length(varargin)
    case 1
        g = varargin{1};
    otherwise
        g = [0.75 0.95 0.75]; % [0.9 0.9 0.9]
end

land = shaperead('landareas', 'UseGeoCoords', true);

f = figure; hold on
%set(gca,'Color',[0.75 0.75 0.95])

fill(land(2).Lon(1640:1950), land(2).Lat(1640:1950), g, 'LineWidth', 2)

fill(land(486).Lon(1:end-1), land(486).Lat(1:end-1), g, 'LineWidth', 2)
fill(land(104).Lon(1:end-1), land(104).Lat(1:end-1), g, 'LineWidth', 2)
fill(land(349).Lon(1:end-1), land(349).Lat(1:end-1), g, 'LineWidth', 2)

fill(land(2).Lon(700:900), land(2).Lat(700:900), g, 'LineWidth', 2)

xlim(lonlim)
ylim(latlim)
xlabel('Longitude')
ylabel('Latitude')

