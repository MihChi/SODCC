% Script used to show how we analyzed the result of the computer
% simulations based on the SODCC algorithm. 
% Consider this main script as an example where the data used is Wind data
% obtained from ERA-Interim database [Dee2011] with the following
% characteristics:
%       - Jan 1979 -- 00:00, 06:00, 12:00, 18:00 -- step = 0
%       - 10 metre U wind component and 10 metre V wind component
%       - Custom area bounded by: 
%           - parallels 35�N and 44�N
%           - meridians 10�W and 6�E
%       - grid = 0.5x0.5
% 
% File output_analysis.mat contains the output of 5000 independent
% simulations
%
% [Dee2011] - Dee, D.P., Uppala, S.M., et al.: The ERA?Interim reanalysis:
% Configuration and performance of the data assimilation system. Quarterly
% Journal of the Royal Meteorological Society 137(656), 553?597 (2011)  

close all; clear all; clc

load('output_analysis');

%% Cluster Size Probability histograms -- CSP
% obtain the cluster size (number of nodes) of all the clusters obtained in
% all the performed simulations. calculate histogram. normalize. plot
aux = horzcat(r{:});
ll = cellfun('length', aux);
ll = ll(ll>0);
[a, b] = hist(ll, 1:max(ll));
a = a./sum(a);

figure; bar(b,a);
xlabel('Cluster size'); ylabel('Probability'); title('CSP, T_j=1979')
clear aux ll a b

%% Node to Cluster Size Probability histograms -- NCSP

N = length(d_ws.estac);
n_cls_size = zeros(1,N);
ind_col_cl = zeros(N,N);
for s = 1:length(r)             % for each simulation
    conf = r{s};
        
    % cluster size
    si = cellfun(@length, conf);
    for cl_size = 1:N
        cls = find(si==cl_size);
        n_cls_size(cl_size) = n_cls_size(cl_size) + length(find(cls));
        for j = 1:length(cls)
            ch = cls(j);
            ind_col_cl(conf{ch},cl_size) = ind_col_cl(conf{ch},cl_size)+1;
        end
    end
end

% prepare colorbar
nun_bins = 1000;    max_colores = round(nun_bins / (5.5/7));    colors = hsv(max_colores); max_colores = round((5.5/7)*max_colores) + 10;

MAX = 0.2;

load('aux_data')        % .mat file that includes data to plot the voronoi region of each node in the network
c = vor.c;  v = vor.v;  clear vor;

latlim = double([min(d_ws.pos(:,2))-2 max(d_ws.pos(:,2))+2]);
lonlim = double([min(d_ws.pos(:,3))-2 max(d_ws.pos(:,3))+2]);
plot_map(latlim, lonlim, [0.9, 0.9, 0.9]); hold all
set(gcf, 'Position', [100 100 1228 755])

colormap(colors(1:max_colores,:)); caxis([0 MAX]); colorbar

ind_col_cl = ind_col_cl ./ repmat(sum(ind_col_cl,2),1,size(ind_col_cl,2));

 cl_size = 7;        % cluster size we want to plot
    
ind_ = sum(ind_col_cl(:,cl_size),2);     
bins = 0:MAX/nun_bins:MAX-MAX/nun_bins;
        
% plot the voronoi regions and the probabilities
for i = d_ws.pos(:,1)'
    c{i}(end+1) = c{i}(1);
    
    find_bin = find(hist(ind_(i), bins)>0);
    color_ahora = colors(find_bin,:);
    
    if ind_(i)> 0
        xx = v(c{i},1);    xx = [xx; xx(1)];
        yy = v(c{i},2);    yy = [yy; yy(1)];
        
        [xx, yy] = poly2ccw(xx, yy);
        fill(yy,xx,color_ahora, 'EdgeColor', 'none');        % plot color
    end
    
end

title('NCSP, T_j=1979, N_i=7')    

      

